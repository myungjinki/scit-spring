package net.dsa.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEx0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
