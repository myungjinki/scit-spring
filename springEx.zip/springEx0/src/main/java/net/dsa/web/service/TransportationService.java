package net.dsa.web.service;

public interface TransportationService {

	public void move();
}
