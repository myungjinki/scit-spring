package net.dsa.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEx0Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringEx0Application.class, args);
	}

}
